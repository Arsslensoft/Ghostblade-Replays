﻿using GhostLib;
using MetroFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ghostblade
{
    public partial class MainForm : XCoolForm.XCoolForm
    {

        void LoadStyle()
        {
            this.TitleBar.TitleBarCaption = "Ghostblade Replays";
            this.TitleBar.TitleBarType = XCoolForm.XTitleBar.XTitleBarType.Rounded;
            this.TitleBar.TitleBarFill = XCoolForm.XTitleBar.XTitleBarFill.LinearRendering;
      

            this.MenuIcon = Ghostblade.Properties.Resources.ghost_white.GetThumbnailImage(24, 24, null, IntPtr.Zero);
            //  this.TitleBar.TitleBarFill = XCoolForm.XTitleBar.XTitleBarFill.AdvancedRendering;
            TitleBar.InnerTitleBarColor = Color.FromArgb(255, 17, 17, 17);
            //   TitleBar.OuterTitleBarColor = Color.FromArgb(255, 240, 230, 235);
            TitleBar.TitleBarMixColors.Add(Color.FromArgb(255, 17, 17, 17));

            this.TitleBar.TitleBarButtons[0].ButtonStyle = XCoolForm.XTitleBarButton.XTitleBarButtonStyle.Pixeled;
            this.TitleBar.TitleBarButtons[0].ButtonFillMode = XCoolForm.XTitleBarButton.XButtonFillMode.UpperGlow;


            this.TitleBar.TitleBarButtons[1].ButtonStyle = XCoolForm.XTitleBarButton.XTitleBarButtonStyle.Pixeled;
            this.TitleBar.TitleBarButtons[1].ButtonFillMode = XCoolForm.XTitleBarButton.XButtonFillMode.UpperGlow;

            this.TitleBar.TitleBarButtons[2].ButtonStyle = XCoolForm.XTitleBarButton.XTitleBarButtonStyle.Pixeled;
            this.TitleBar.TitleBarButtons[2].ButtonFillMode = XCoolForm.XTitleBarButton.XButtonFillMode.UpperGlow;



        }
        public MainForm()
        {

            InitializeComponent();
            LoadStyle();
            MainTopBanner.Switch(true);
        }

        void ReplayResize()
        {

            ReplayPanelHost.Width = replaybx.Width - 6;
            ReplayPanelHost.Height = replaybx.Height - 46;
            ReplayPanelHost.Location = new Point(3, 43);

        }
        void HomeResize()
        {
            recordingbx.Height =HomeTab.Height - 271;
            svstatbx.Width = recordingbx.Width - 471;
            shardInfoControl1.Width = svstatbx.Width - 8;
       
            RecordingPanelHost.Width = recordingbx.Width - 6;
            RecordingPanelHost.Height = recordingbx.Height - 46;
            RecordingPanelHost.Location = new Point(3, 43);


        }
        private void MainForm_Resize(object sender, EventArgs e)
        {
            this.MainPanel.Size = new Size(this.MainPanel.Size.Width, this.Height - 44);
            HomeResize(); 
            ReplayResize();
        }
        private void nsTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MainForm_Resize(this, EventArgs.Empty);
        }


        #region Featured Games
        List<FeaturedGameControl> FeaturedGames = new List<FeaturedGameControl>();
        public FeaturedGameControl SelectedFeaturedGame { get; set; }
        Random rd = new Random();
        void SelectGame(int id)
        {
            if (FeaturedGames.Count == 0 || id >= FeaturedGames.Count)
                return;

            SelectedFeaturedGame = FeaturedGames[id];

            specfeaturedbtn.Visible = (SelectedFeaturedGame != null);
            recfeaturedbtn.Visible = (SelectedFeaturedGame != null);


            CurrentFeaturedGamePanel.Controls.Clear();

            SelectedFeaturedGame.Visible = false;
            animator1.AnimationType = AnimatorNS.AnimationType.ScaleAndHorizSlide;
            CurrentFeaturedGamePanel.Controls.Add(SelectedFeaturedGame);
            animator1.Show(SelectedFeaturedGame);

          
        }
        private void metroComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
               // Remove all featured games
                FeaturedGames.Clear();
                CurrentFeaturedGamePanel.Controls.Clear();
                SelectedFeaturedGame = null;

                // Find Games
                string server = metroComboBox1.Text;


                string plat = RiotTool.RegionToPlatformId(server);


                if (RiotTool.Servers.ContainsKey(plat))
                {

                    RiotSharp.Featured.FeaturedGames fg = GhostBase.GhostbladeInstance.Api.GetFeaturedGames(RiotTool.Servers[plat]);
                    featuredgamespaginator.NumberOfPages = fg.gameList.Count;
                    specfeaturedbtn.Visible = (fg.gameList.Count != 0);
                    recfeaturedbtn.Visible = (fg.gameList.Count != 0);
                    if (fg.gameList.Count == 0)
                    {
                  
                        ginfo.Text = "Unable to get featured games from this server";
                        ginfo.Visible = false;
                        animator1.AnimationType = AnimatorNS.AnimationType.VertSlide;
                        CurrentFeaturedGamePanel.Controls.Add(ginfo);
                        animator1.Show(ginfo);
                    }
                    else
                    {

                        foreach (RiotSharp.Featured.GameList gl in fg.gameList)
                        {
                            FeaturedGameControl ctrl = new FeaturedGameControl();
                            ctrl.LoadFeatured(gl);
                            ctrl.Dock = DockStyle.Fill;
                            //ctrl.BorderStyle = BorderStyle.Fixed3D;
                            FeaturedGames.Add(ctrl);

                           

                        }
                        SelectGame(0);
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " \n" + ex.StackTrace);
             //   metroTabPage3.Controls.Add(ginfo);
            }
            finally
            {
            //    metroTabPage3.Controls.Add(panel3);
            }
        }

     

        private void featuredgamespaginator_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectGame(featuredgamespaginator.SelectedIndex);
        }
        private void recfeaturedbtn_Click(object sender, EventArgs e)
        {

            //if (SelectedFeaturedGame != null)
            //{
            //    if (RiotTool.Servers.ContainsKey(SelectedFeaturedGame.CurrentGame.platformId.ToUpper()))
            //        this.SimulateRecordFeatured(SelectedFeaturedGame.CurrentGame, RiotTool.Servers[SelectedFeaturedGame.CurrentGame.platformId.ToUpper()]);
            //    else
            //        MetroMessageBox.Show(this, "Could not record this game", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else
            //    MetroMessageBox.Show(this, "Could not record this game", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void specfeaturedbtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (SelectedFeaturedGame == null)
                    return;
                if (Process.GetProcessesByName("League of Legends").Length != 0)
                {
                    MetroMessageBox.Show(this, "Could not open League of Legends.\nAnother instance is running.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
                }
                string[] details = new string[2] { SelectedFeaturedGame.CurrentGame.gameId.ToString(), SelectedFeaturedGame.CurrentGame.platformId };
                Process p = new System.Diagnostics.Process();
                p.StartInfo.WorkingDirectory = RiotTool.Instance.GetLatestGameReleaseDeploy();
                p.StartInfo.FileName = RiotTool.Instance.GameExecutable;
                p.StartInfo.Arguments = "\"8394\" \"LoLLauncher.exe\" \"\" \"spectator "
                    + RiotTool.Servers[SelectedFeaturedGame.CurrentGame.platformId.ToUpper()] + " "
                    + SelectedFeaturedGame.CurrentGame.observers.encryptionKey + " "
                    + details[0] + " "
                    + details[1] + "\"";

                p.Start();
                GhostOverlay.ShowOverlay(p.StartInfo.WorkingDirectory);
            }
            catch (Exception ex)
            {
                Logger.Instance.Log.Warn("Failed to spectate record", ex);
            }
        }
        #endregion

  

   

   
    }
}
