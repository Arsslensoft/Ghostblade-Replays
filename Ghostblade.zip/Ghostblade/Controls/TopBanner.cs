﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ghostblade
{
    public partial class TopBanner : UserControl
    {
        public TopBanner()
        {
            InitializeComponent();
  
        }
        public void Switch(bool banner)
        {
            if (banner)
            {
                panel1.Visible = true;
                this.Height = 86;
            }
            else
            {
                panel3.Visible = true;
                this.Height = 60;
            }
        }
        private void TopBanner_Resize(object sender, EventArgs e)
        {

        }

     
    }
}
