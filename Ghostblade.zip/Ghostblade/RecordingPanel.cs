﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GhostLib.Gui;

namespace Ghostblade
{
    partial class RecordingPanel : GPanel
    {
        public RecordingPanel()
        {
            InitializeComponent();
        }

        private void RecordingPanel_Resize(object sender, EventArgs e)
        {
            panel3.Location = new Point(3, 3);
            panel3.Width = this.Size.Width - 6;
            panel3.Height = this.Height  -6;
        }
    }
}
