﻿namespace Ghostblade
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            AnimatorNS.Animation animation1 = new AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MainPanel = new System.Windows.Forms.Panel();
            this.MainTabControl = new GhostLib.Gui.NSTabControl();
            this.HomeTab = new System.Windows.Forms.TabPage();
            this.recordingbx = new GhostLib.Gui.NSGroupBox();
            this.RecordingPanelHost = new MetroFramework.Controls.MetroPanel();
            this.recordingPanel1 = new Ghostblade.RecordingPanel();
            this.svstatbx = new GhostLib.Gui.NSGroupBox();
            this.shardInfoControl1 = new Ghostblade.ShardInfoControl();
            this.featuredbx = new GhostLib.Gui.NSGroupBox();
            this.FeaturedGamesPanel = new System.Windows.Forms.Panel();
            this.recfeaturedbtn = new MetroFramework.Controls.MetroButton();
            this.specfeaturedbtn = new MetroFramework.Controls.MetroButton();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.featuredgamespaginator = new GhostLib.Gui.NSPaginator();
            this.CurrentFeaturedGamePanel = new System.Windows.Forms.Panel();
            this.ginfo = new MetroFramework.Controls.MetroLabel();
            this.ReplaysTab = new System.Windows.Forms.TabPage();
            this.replaybx = new GhostLib.Gui.NSGroupBox();
            this.ReplayPanelHost = new MetroFramework.Controls.MetroPanel();
            this.replayPanel1 = new Ghostblade.ReplayPanel();
            this.MainTopBanner = new Ghostblade.TopBanner();
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.animator1 = new AnimatorNS.Animator(this.components);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.MainPanel.SuspendLayout();
            this.MainTabControl.SuspendLayout();
            this.HomeTab.SuspendLayout();
            this.recordingbx.SuspendLayout();
            this.RecordingPanelHost.SuspendLayout();
            this.svstatbx.SuspendLayout();
            this.featuredbx.SuspendLayout();
            this.FeaturedGamesPanel.SuspendLayout();
            this.CurrentFeaturedGamePanel.SuspendLayout();
            this.ReplaysTab.SuspendLayout();
            this.replaybx.SuspendLayout();
            this.ReplayPanelHost.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // MainPanel
            // 
            this.MainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.MainPanel.Controls.Add(this.MainTabControl);
            this.MainPanel.Controls.Add(this.MainTopBanner);
            this.animator1.SetDecoration(this.MainPanel, AnimatorNS.DecorationType.None);
            this.MainPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.MainPanel.Location = new System.Drawing.Point(8, 50);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(1135, 599);
            this.MainPanel.TabIndex = 0;
            // 
            // MainTabControl
            // 
            this.MainTabControl.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.MainTabControl.Controls.Add(this.HomeTab);
            this.MainTabControl.Controls.Add(this.ReplaysTab);
            this.MainTabControl.Controls.Add(this.tabPage1);
            this.animator1.SetDecoration(this.MainTabControl, AnimatorNS.DecorationType.None);
            this.MainTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTabControl.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.MainTabControl.ItemSize = new System.Drawing.Size(28, 115);
            this.MainTabControl.Location = new System.Drawing.Point(0, 86);
            this.MainTabControl.Multiline = true;
            this.MainTabControl.Name = "MainTabControl";
            this.MainTabControl.SelectedIndex = 0;
            this.MainTabControl.Size = new System.Drawing.Size(1135, 513);
            this.MainTabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.MainTabControl.TabIndex = 6;
            this.MainTabControl.SelectedIndexChanged += new System.EventHandler(this.nsTabControl1_SelectedIndexChanged);
            // 
            // HomeTab
            // 
            this.HomeTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.HomeTab.Controls.Add(this.recordingbx);
            this.HomeTab.Controls.Add(this.svstatbx);
            this.HomeTab.Controls.Add(this.featuredbx);
            this.animator1.SetDecoration(this.HomeTab, AnimatorNS.DecorationType.None);
            this.HomeTab.Location = new System.Drawing.Point(119, 4);
            this.HomeTab.Name = "HomeTab";
            this.HomeTab.Padding = new System.Windows.Forms.Padding(3);
            this.HomeTab.Size = new System.Drawing.Size(1012, 505);
            this.HomeTab.TabIndex = 0;
            this.HomeTab.Text = "Home";
            // 
            // recordingbx
            // 
            this.recordingbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.recordingbx.Controls.Add(this.RecordingPanelHost);
            this.animator1.SetDecoration(this.recordingbx, AnimatorNS.DecorationType.None);
            this.recordingbx.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.recordingbx.DrawSeperator = true;
            this.recordingbx.Location = new System.Drawing.Point(3, 268);
            this.recordingbx.Name = "recordingbx";
            this.recordingbx.Size = new System.Drawing.Size(1006, 234);
            this.recordingbx.SubTitle = "0 Games recording";
            this.recordingbx.TabIndex = 4;
            this.recordingbx.Title = "Recording";
            // 
            // RecordingPanelHost
            // 
            this.RecordingPanelHost.AutoScroll = true;
            this.RecordingPanelHost.Controls.Add(this.recordingPanel1);
            this.animator1.SetDecoration(this.RecordingPanelHost, AnimatorNS.DecorationType.None);
            this.RecordingPanelHost.HorizontalScrollbar = true;
            this.RecordingPanelHost.HorizontalScrollbarBarColor = true;
            this.RecordingPanelHost.HorizontalScrollbarHighlightOnWheel = false;
            this.RecordingPanelHost.HorizontalScrollbarSize = 10;
            this.RecordingPanelHost.Location = new System.Drawing.Point(3, 43);
            this.RecordingPanelHost.Name = "RecordingPanelHost";
            this.RecordingPanelHost.Size = new System.Drawing.Size(1000, 188);
            this.RecordingPanelHost.TabIndex = 6;
            this.RecordingPanelHost.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.RecordingPanelHost.VerticalScrollbar = true;
            this.RecordingPanelHost.VerticalScrollbarBarColor = true;
            this.RecordingPanelHost.VerticalScrollbarHighlightOnWheel = false;
            this.RecordingPanelHost.VerticalScrollbarSize = 10;
            // 
            // recordingPanel1
            // 
            this.recordingPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.animator1.SetDecoration(this.recordingPanel1, AnimatorNS.DecorationType.None);
            this.recordingPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.recordingPanel1.Location = new System.Drawing.Point(0, 0);
            this.recordingPanel1.Name = "recordingPanel1";
            this.recordingPanel1.Size = new System.Drawing.Size(1000, 47);
            this.recordingPanel1.TabIndex = 5;
            // 
            // svstatbx
            // 
            this.svstatbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.svstatbx.Controls.Add(this.shardInfoControl1);
            this.animator1.SetDecoration(this.svstatbx, AnimatorNS.DecorationType.None);
            this.svstatbx.DrawSeperator = false;
            this.svstatbx.Location = new System.Drawing.Point(471, 6);
            this.svstatbx.Name = "svstatbx";
            this.svstatbx.Size = new System.Drawing.Size(533, 256);
            this.svstatbx.SubTitle = "Server Status";
            this.svstatbx.TabIndex = 3;
            this.svstatbx.Title = "Europe West";
            // 
            // shardInfoControl1
            // 
            this.shardInfoControl1.AutoScroll = true;
            this.shardInfoControl1.BackColor = System.Drawing.Color.Transparent;
            this.animator1.SetDecoration(this.shardInfoControl1, AnimatorNS.DecorationType.None);
            this.shardInfoControl1.Location = new System.Drawing.Point(3, 49);
            this.shardInfoControl1.Name = "shardInfoControl1";
            this.shardInfoControl1.Size = new System.Drawing.Size(525, 204);
            this.shardInfoControl1.TabIndex = 0;
            // 
            // featuredbx
            // 
            this.featuredbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.featuredbx.Controls.Add(this.FeaturedGamesPanel);
            this.animator1.SetDecoration(this.featuredbx, AnimatorNS.DecorationType.None);
            this.featuredbx.DrawSeperator = false;
            this.featuredbx.Location = new System.Drawing.Point(3, 6);
            this.featuredbx.Name = "featuredbx";
            this.featuredbx.Size = new System.Drawing.Size(462, 256);
            this.featuredbx.SubTitle = "";
            this.featuredbx.TabIndex = 1;
            this.featuredbx.Title = "Featured Games";
            // 
            // FeaturedGamesPanel
            // 
            this.FeaturedGamesPanel.Controls.Add(this.recfeaturedbtn);
            this.FeaturedGamesPanel.Controls.Add(this.specfeaturedbtn);
            this.FeaturedGamesPanel.Controls.Add(this.metroComboBox1);
            this.FeaturedGamesPanel.Controls.Add(this.featuredgamespaginator);
            this.FeaturedGamesPanel.Controls.Add(this.CurrentFeaturedGamePanel);
            this.animator1.SetDecoration(this.FeaturedGamesPanel, AnimatorNS.DecorationType.None);
            this.FeaturedGamesPanel.Location = new System.Drawing.Point(8, 38);
            this.FeaturedGamesPanel.Name = "FeaturedGamesPanel";
            this.FeaturedGamesPanel.Size = new System.Drawing.Size(448, 215);
            this.FeaturedGamesPanel.TabIndex = 0;
            // 
            // recfeaturedbtn
            // 
            this.animator1.SetDecoration(this.recfeaturedbtn, AnimatorNS.DecorationType.None);
            this.recfeaturedbtn.Location = new System.Drawing.Point(377, 181);
            this.recfeaturedbtn.Name = "recfeaturedbtn";
            this.recfeaturedbtn.Size = new System.Drawing.Size(68, 28);
            this.recfeaturedbtn.TabIndex = 8;
            this.recfeaturedbtn.Text = "Record";
            this.recfeaturedbtn.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.recfeaturedbtn.UseSelectable = true;
            this.recfeaturedbtn.Click += new System.EventHandler(this.recfeaturedbtn_Click);
            // 
            // specfeaturedbtn
            // 
            this.animator1.SetDecoration(this.specfeaturedbtn, AnimatorNS.DecorationType.None);
            this.specfeaturedbtn.Location = new System.Drawing.Point(312, 181);
            this.specfeaturedbtn.Name = "specfeaturedbtn";
            this.specfeaturedbtn.Size = new System.Drawing.Size(68, 28);
            this.specfeaturedbtn.TabIndex = 9;
            this.specfeaturedbtn.Text = "Spectate";
            this.specfeaturedbtn.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.specfeaturedbtn.UseSelectable = true;
            this.specfeaturedbtn.Click += new System.EventHandler(this.specfeaturedbtn_Click);
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.animator1.SetDecoration(this.metroComboBox1, AnimatorNS.DecorationType.None);
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Items.AddRange(new object[] {
            "NA",
            "EUW",
            "BR",
            "KR",
            "TR",
            "EUNE",
            "RU",
            "OCE",
            "LAN",
            "LAS",
            "TW",
            "PBE1",
            "VN",
            "PH",
            "TH",
            "ID1",
            "TRSA",
            "TRNA",
            "TRTW",
            "HN1_NEW"});
            this.metroComboBox1.Location = new System.Drawing.Point(3, 180);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(94, 29);
            this.metroComboBox1.TabIndex = 7;
            this.metroComboBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroComboBox1.UseSelectable = true;
            this.metroComboBox1.SelectedIndexChanged += new System.EventHandler(this.metroComboBox1_SelectedIndexChanged);
            // 
            // featuredgamespaginator
            // 
            this.animator1.SetDecoration(this.featuredgamespaginator, AnimatorNS.DecorationType.None);
            this.featuredgamespaginator.Location = new System.Drawing.Point(103, 181);
            this.featuredgamespaginator.Name = "featuredgamespaginator";
            this.featuredgamespaginator.NumberOfPages = 5;
            this.featuredgamespaginator.SelectedIndex = 0;
            this.featuredgamespaginator.Size = new System.Drawing.Size(203, 26);
            this.featuredgamespaginator.TabIndex = 1;
            this.featuredgamespaginator.Text = "Featured Games";
            this.featuredgamespaginator.SelectedIndexChanged += new GhostLib.Gui.NSPaginator.SelectedIndexChangedEventHandler(this.featuredgamespaginator_SelectedIndexChanged);
            // 
            // CurrentFeaturedGamePanel
            // 
            this.CurrentFeaturedGamePanel.Controls.Add(this.ginfo);
            this.animator1.SetDecoration(this.CurrentFeaturedGamePanel, AnimatorNS.DecorationType.None);
            this.CurrentFeaturedGamePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.CurrentFeaturedGamePanel.Location = new System.Drawing.Point(0, 0);
            this.CurrentFeaturedGamePanel.Name = "CurrentFeaturedGamePanel";
            this.CurrentFeaturedGamePanel.Size = new System.Drawing.Size(448, 174);
            this.CurrentFeaturedGamePanel.TabIndex = 0;
            // 
            // ginfo
            // 
            this.ginfo.AutoSize = true;
            this.animator1.SetDecoration(this.ginfo, AnimatorNS.DecorationType.None);
            this.ginfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ginfo.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.ginfo.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.ginfo.Location = new System.Drawing.Point(0, 0);
            this.ginfo.Name = "ginfo";
            this.ginfo.Size = new System.Drawing.Size(0, 0);
            this.ginfo.TabIndex = 10;
            this.ginfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ginfo.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // ReplaysTab
            // 
            this.ReplaysTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.ReplaysTab.Controls.Add(this.replaybx);
            this.animator1.SetDecoration(this.ReplaysTab, AnimatorNS.DecorationType.None);
            this.ReplaysTab.Location = new System.Drawing.Point(119, 4);
            this.ReplaysTab.Name = "ReplaysTab";
            this.ReplaysTab.Padding = new System.Windows.Forms.Padding(3);
            this.ReplaysTab.Size = new System.Drawing.Size(1012, 505);
            this.ReplaysTab.TabIndex = 1;
            this.ReplaysTab.Text = "Replays";
            // 
            // replaybx
            // 
            this.replaybx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.replaybx.Controls.Add(this.ReplayPanelHost);
            this.animator1.SetDecoration(this.replaybx, AnimatorNS.DecorationType.None);
            this.replaybx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.replaybx.DrawSeperator = true;
            this.replaybx.Location = new System.Drawing.Point(3, 3);
            this.replaybx.Name = "replaybx";
            this.replaybx.Size = new System.Drawing.Size(1006, 499);
            this.replaybx.SubTitle = "1 Replay - 1 Win 0 Losses";
            this.replaybx.TabIndex = 5;
            this.replaybx.Title = "Replays";
            // 
            // ReplayPanelHost
            // 
            this.ReplayPanelHost.AutoScroll = true;
            this.ReplayPanelHost.Controls.Add(this.replayPanel1);
            this.animator1.SetDecoration(this.ReplayPanelHost, AnimatorNS.DecorationType.None);
            this.ReplayPanelHost.HorizontalScrollbar = true;
            this.ReplayPanelHost.HorizontalScrollbarBarColor = true;
            this.ReplayPanelHost.HorizontalScrollbarHighlightOnWheel = false;
            this.ReplayPanelHost.HorizontalScrollbarSize = 10;
            this.ReplayPanelHost.Location = new System.Drawing.Point(3, 43);
            this.ReplayPanelHost.Name = "ReplayPanelHost";
            this.ReplayPanelHost.Size = new System.Drawing.Size(1000, 188);
            this.ReplayPanelHost.TabIndex = 6;
            this.ReplayPanelHost.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.ReplayPanelHost.VerticalScrollbar = true;
            this.ReplayPanelHost.VerticalScrollbarBarColor = true;
            this.ReplayPanelHost.VerticalScrollbarHighlightOnWheel = false;
            this.ReplayPanelHost.VerticalScrollbarSize = 10;
            // 
            // replayPanel1
            // 
            this.replayPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.animator1.SetDecoration(this.replayPanel1, AnimatorNS.DecorationType.None);
            this.replayPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.replayPanel1.Location = new System.Drawing.Point(0, 0);
            this.replayPanel1.Name = "replayPanel1";
            this.replayPanel1.Size = new System.Drawing.Size(1000, 57);
            this.replayPanel1.TabIndex = 2;
            this.replayPanel1.Text = "replayPanel1";
            // 
            // MainTopBanner
            // 
            this.MainTopBanner.BackColor = System.Drawing.Color.Transparent;
            this.animator1.SetDecoration(this.MainTopBanner, AnimatorNS.DecorationType.None);
            this.MainTopBanner.Dock = System.Windows.Forms.DockStyle.Top;
            this.MainTopBanner.Location = new System.Drawing.Point(0, 0);
            this.MainTopBanner.Name = "MainTopBanner";
            this.MainTopBanner.Size = new System.Drawing.Size(1135, 86);
            this.MainTopBanner.TabIndex = 5;
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = this;
            // 
            // animator1
            // 
            this.animator1.AnimationType = AnimatorNS.AnimationType.Particles;
            this.animator1.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 1;
            animation1.Padding = new System.Windows.Forms.Padding(100, 50, 100, 150);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 2F;
            animation1.TransparencyCoeff = 0F;
            this.animator1.DefaultAnimation = animation1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.animator1.SetDecoration(this.tabPage1, AnimatorNS.DecorationType.None);
            this.tabPage1.Location = new System.Drawing.Point(119, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1012, 505);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Current Games";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1151, 657);
            this.Controls.Add(this.MainPanel);
            this.animator1.SetDecoration(this, AnimatorNS.DecorationType.None);
            this.MenuIconInnerBorder = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.MainPanel.ResumeLayout(false);
            this.MainTabControl.ResumeLayout(false);
            this.HomeTab.ResumeLayout(false);
            this.recordingbx.ResumeLayout(false);
            this.RecordingPanelHost.ResumeLayout(false);
            this.svstatbx.ResumeLayout(false);
            this.featuredbx.ResumeLayout(false);
            this.FeaturedGamesPanel.ResumeLayout(false);
            this.CurrentFeaturedGamePanel.ResumeLayout(false);
            this.CurrentFeaturedGamePanel.PerformLayout();
            this.ReplaysTab.ResumeLayout(false);
            this.replaybx.ResumeLayout(false);
            this.ReplayPanelHost.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private System.Windows.Forms.Panel MainPanel;
        private TopBanner MainTopBanner;
        private GhostLib.Gui.NSTabControl MainTabControl;
        private System.Windows.Forms.TabPage HomeTab;
        private System.Windows.Forms.TabPage ReplaysTab;
        private System.Windows.Forms.Panel FeaturedGamesPanel;
        private System.Windows.Forms.Panel CurrentFeaturedGamePanel;
        private GhostLib.Gui.NSPaginator featuredgamespaginator;
        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroLabel ginfo;
        private AnimatorNS.Animator animator1;
        private MetroFramework.Controls.MetroButton recfeaturedbtn;
        private MetroFramework.Controls.MetroButton specfeaturedbtn;
        private GhostLib.Gui.NSGroupBox featuredbx;
        private GhostLib.Gui.NSGroupBox svstatbx;
        private ShardInfoControl shardInfoControl1;
        private GhostLib.Gui.NSGroupBox recordingbx;
        private RecordingPanel recordingPanel1;
        private MetroFramework.Controls.MetroPanel RecordingPanelHost;
        private GhostLib.Gui.NSGroupBox replaybx;
        private MetroFramework.Controls.MetroPanel ReplayPanelHost;
        private ReplayPanel replayPanel1;
        private System.Windows.Forms.TabPage tabPage1;

    }
}

