﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GhostLib.Gui;

namespace Ghostblade
{
    partial class ReplayPanel : GPanel
    {
        public ReplayPanel()
        {
            InitializeComponent();
        }

        private void ReplayPanel_Resize(object sender, EventArgs e)
        {
            panel1.Location = new Point(3, 3);
            panel1.Width = this.Size.Width - 6;
            panel1.Height = this.Height - 6;
        }
    }
}
