﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ghostblade
{
    public partial class ShardInfoControl : UserControl
    {
        public ShardInfoControl()
        {
            InitializeComponent();
            timer1.Enabled = true;
            MethodInvoker mtd = new MethodInvoker(LoadShard);
            mtd.BeginInvoke(null, null);
        }

        public void AddService(RiotSharp.StatusEndpoint.Service svc)
        {
            if(svc.Incidents.Count == 0)
                svc.Status = char.ToUpper(svc.Status[0]) + svc.Status.Remove(0, 1);
            else {svc.Status =char.ToUpper( svc.Status[0]) + svc.Status.Remove(0,1) + " with some incidents";

            }
            switch (svc.Slug)
            {

                case "game":
                    gamebx.SubTitle = svc.Status;
                    break;
                case "web":
                    webbx.SubTitle = svc.Status;
                    break;
                case "store":
                    storebx.SubTitle = svc.Status;
                    break;
                case "forums":
                case "boards":
                    forumbx.SubTitle = svc.Status;
                    break;
            }
        }

        public void LoadShardStatus(RiotSharp.StatusEndpoint.ShardStatus ss)
        {
            foreach (RiotSharp.StatusEndpoint.Service svc in ss.Services)
                AddService(svc);
        }

        void LoadShard()
        {
            try
            {
                RiotSharp.StatusRiotApi SAPI = RiotSharp.StatusRiotApi.GetInstance();
                RiotSharp.StatusEndpoint.ShardStatus ss = SAPI.GetShardStatus( RiotSharp.Region.euw);
                this.BeginInvoke(new MethodInvoker(delegate
                {
                    LoadShardStatus(ss);
                }));

            }
            catch
            {

            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            MethodInvoker mtd = new MethodInvoker(LoadShard);
            mtd.BeginInvoke(null, null);
        }

    }
}
