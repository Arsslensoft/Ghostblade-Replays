﻿using GhostLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Ghostblade
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            // Api cache
            //RiotSharp.ApiCache.CacheEnabled = SettingsManager.Settings.ApiCacheEnabled;
            //RiotSharp.ApiCache.Initialize();

            // Register App
            ApplicationInstance.Instance.Register("CID");
            GhostBase.GhostbladeInstance.Init();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
