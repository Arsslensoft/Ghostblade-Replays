﻿namespace Ghostblade
{
    partial class Player2Ctrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Spell2 = new System.Windows.Forms.PictureBox();
            this.Spell1 = new System.Windows.Forms.PictureBox();
            this.Champion = new System.Windows.Forms.PictureBox();
            this.item1 = new System.Windows.Forms.PictureBox();
            this.item2 = new System.Windows.Forms.PictureBox();
            this.item3 = new System.Windows.Forms.PictureBox();
            this.item4 = new System.Windows.Forms.PictureBox();
            this.item5 = new System.Windows.Forms.PictureBox();
            this.item6 = new System.Windows.Forms.PictureBox();
            this.item7 = new System.Windows.Forms.PictureBox();
            this.lmkslb = new MetroFramework.Controls.MetroLabel();
            this.dmgdealtlb = new MetroFramework.Controls.MetroLabel();
            this.dmgtakenlb = new MetroFramework.Controls.MetroLabel();
            this.Turretdestlb = new MetroFramework.Controls.MetroLabel();
            this.wardkilledlb = new MetroFramework.Controls.MetroLabel();
            this.wardplacedlb = new MetroFramework.Controls.MetroLabel();
            this.creepslb = new MetroFramework.Controls.MetroLabel();
            this.goldlb = new MetroFramework.Controls.MetroLabel();
            this.KDAlb = new MetroFramework.Controls.MetroLabel();
            this.summoner = new MetroFramework.Controls.MetroLink();
            ((System.ComponentModel.ISupportInitialize)(this.Spell2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spell1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Champion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.item7)).BeginInit();
            this.SuspendLayout();
            // 
            // Spell2
            // 
            this.Spell2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Spell2.Location = new System.Drawing.Point(183, 18);
            this.Spell2.Name = "Spell2";
            this.Spell2.Size = new System.Drawing.Size(16, 16);
            this.Spell2.TabIndex = 10;
            this.Spell2.TabStop = false;
            // 
            // Spell1
            // 
            this.Spell1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Spell1.Location = new System.Drawing.Point(183, 2);
            this.Spell1.Name = "Spell1";
            this.Spell1.Size = new System.Drawing.Size(16, 16);
            this.Spell1.TabIndex = 9;
            this.Spell1.TabStop = false;
            // 
            // Champion
            // 
            this.Champion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Champion.Location = new System.Drawing.Point(145, 2);
            this.Champion.Name = "Champion";
            this.Champion.Size = new System.Drawing.Size(32, 32);
            this.Champion.TabIndex = 8;
            this.Champion.TabStop = false;
            this.Champion.Click += new System.EventHandler(this.Champion_Click);
            this.Champion.MouseEnter += new System.EventHandler(this.Champion_MouseEnter);
            // 
            // item1
            // 
            this.item1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.item1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.item1.Location = new System.Drawing.Point(352, 2);
            this.item1.Name = "item1";
            this.item1.Size = new System.Drawing.Size(32, 32);
            this.item1.TabIndex = 12;
            this.item1.TabStop = false;
            // 
            // item2
            // 
            this.item2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.item2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.item2.Location = new System.Drawing.Point(385, 2);
            this.item2.Name = "item2";
            this.item2.Size = new System.Drawing.Size(32, 32);
            this.item2.TabIndex = 13;
            this.item2.TabStop = false;
            // 
            // item3
            // 
            this.item3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.item3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.item3.Location = new System.Drawing.Point(418, 2);
            this.item3.Name = "item3";
            this.item3.Size = new System.Drawing.Size(32, 32);
            this.item3.TabIndex = 14;
            this.item3.TabStop = false;
            // 
            // item4
            // 
            this.item4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.item4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.item4.Location = new System.Drawing.Point(451, 2);
            this.item4.Name = "item4";
            this.item4.Size = new System.Drawing.Size(32, 32);
            this.item4.TabIndex = 15;
            this.item4.TabStop = false;
            // 
            // item5
            // 
            this.item5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.item5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.item5.Location = new System.Drawing.Point(484, 2);
            this.item5.Name = "item5";
            this.item5.Size = new System.Drawing.Size(32, 32);
            this.item5.TabIndex = 16;
            this.item5.TabStop = false;
            // 
            // item6
            // 
            this.item6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.item6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.item6.Location = new System.Drawing.Point(517, 2);
            this.item6.Name = "item6";
            this.item6.Size = new System.Drawing.Size(32, 32);
            this.item6.TabIndex = 17;
            this.item6.TabStop = false;
            // 
            // item7
            // 
            this.item7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.item7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.item7.Location = new System.Drawing.Point(550, 2);
            this.item7.Name = "item7";
            this.item7.Size = new System.Drawing.Size(32, 32);
            this.item7.TabIndex = 18;
            this.item7.TabStop = false;
            // 
            // lmkslb
            // 
            this.lmkslb.Location = new System.Drawing.Point(283, 4);
            this.lmkslb.Name = "lmkslb";
            this.lmkslb.Size = new System.Drawing.Size(66, 23);
            this.lmkslb.Style = MetroFramework.MetroColorStyle.Blue;
            this.lmkslb.TabIndex = 26;
            this.lmkslb.Text = "0 | 0";
            this.lmkslb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lmkslb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.lmkslb.UseSelectable = true;
            this.lmkslb.UseStyleColors = true;
            // 
            // dmgdealtlb
            // 
            this.dmgdealtlb.Location = new System.Drawing.Point(919, 4);
            this.dmgdealtlb.Name = "dmgdealtlb";
            this.dmgdealtlb.Size = new System.Drawing.Size(60, 23);
            this.dmgdealtlb.Style = MetroFramework.MetroColorStyle.Blue;
            this.dmgdealtlb.TabIndex = 25;
            this.dmgdealtlb.Text = "0";
            this.dmgdealtlb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.dmgdealtlb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.dmgdealtlb.UseSelectable = true;
            this.dmgdealtlb.UseStyleColors = true;
            // 
            // dmgtakenlb
            // 
            this.dmgtakenlb.Location = new System.Drawing.Point(855, 4);
            this.dmgtakenlb.Name = "dmgtakenlb";
            this.dmgtakenlb.Size = new System.Drawing.Size(60, 23);
            this.dmgtakenlb.Style = MetroFramework.MetroColorStyle.Blue;
            this.dmgtakenlb.TabIndex = 24;
            this.dmgtakenlb.Text = "0";
            this.dmgtakenlb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.dmgtakenlb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.dmgtakenlb.UseSelectable = true;
            this.dmgtakenlb.UseStyleColors = true;
            // 
            // Turretdestlb
            // 
            this.Turretdestlb.Location = new System.Drawing.Point(807, 4);
            this.Turretdestlb.Name = "Turretdestlb";
            this.Turretdestlb.Size = new System.Drawing.Size(43, 23);
            this.Turretdestlb.Style = MetroFramework.MetroColorStyle.Blue;
            this.Turretdestlb.TabIndex = 23;
            this.Turretdestlb.Text = "0";
            this.Turretdestlb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Turretdestlb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Turretdestlb.UseSelectable = true;
            this.Turretdestlb.UseStyleColors = true;
            // 
            // wardkilledlb
            // 
            this.wardkilledlb.Location = new System.Drawing.Point(759, 4);
            this.wardkilledlb.Name = "wardkilledlb";
            this.wardkilledlb.Size = new System.Drawing.Size(44, 23);
            this.wardkilledlb.Style = MetroFramework.MetroColorStyle.Blue;
            this.wardkilledlb.TabIndex = 22;
            this.wardkilledlb.Text = "0";
            this.wardkilledlb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.wardkilledlb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.wardkilledlb.UseSelectable = true;
            this.wardkilledlb.UseStyleColors = true;
            // 
            // wardplacedlb
            // 
            this.wardplacedlb.Location = new System.Drawing.Point(717, 4);
            this.wardplacedlb.Name = "wardplacedlb";
            this.wardplacedlb.Size = new System.Drawing.Size(39, 23);
            this.wardplacedlb.Style = MetroFramework.MetroColorStyle.Blue;
            this.wardplacedlb.TabIndex = 21;
            this.wardplacedlb.Text = "0";
            this.wardplacedlb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.wardplacedlb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.wardplacedlb.UseSelectable = true;
            this.wardplacedlb.UseStyleColors = true;
            // 
            // creepslb
            // 
            this.creepslb.Location = new System.Drawing.Point(659, 4);
            this.creepslb.Name = "creepslb";
            this.creepslb.Size = new System.Drawing.Size(55, 23);
            this.creepslb.Style = MetroFramework.MetroColorStyle.Blue;
            this.creepslb.TabIndex = 20;
            this.creepslb.Text = "0";
            this.creepslb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.creepslb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.creepslb.UseSelectable = true;
            this.creepslb.UseStyleColors = true;
            // 
            // goldlb
            // 
            this.goldlb.Location = new System.Drawing.Point(588, 4);
            this.goldlb.Name = "goldlb";
            this.goldlb.Size = new System.Drawing.Size(69, 23);
            this.goldlb.Style = MetroFramework.MetroColorStyle.Blue;
            this.goldlb.TabIndex = 19;
            this.goldlb.Text = "0 $";
            this.goldlb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.goldlb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.goldlb.UseSelectable = true;
            this.goldlb.UseStyleColors = true;
            // 
            // KDAlb
            // 
            this.KDAlb.Location = new System.Drawing.Point(203, 4);
            this.KDAlb.Name = "KDAlb";
            this.KDAlb.Size = new System.Drawing.Size(77, 23);
            this.KDAlb.Style = MetroFramework.MetroColorStyle.Blue;
            this.KDAlb.TabIndex = 11;
            this.KDAlb.Text = "0 / 0 / 0";
            this.KDAlb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.KDAlb.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.KDAlb.UseSelectable = true;
            this.KDAlb.UseStyleColors = true;
            // 
            // summoner
            // 
            this.summoner.Location = new System.Drawing.Point(3, 6);
            this.summoner.Name = "summoner";
            this.summoner.Size = new System.Drawing.Size(138, 23);
            this.summoner.Style = MetroFramework.MetroColorStyle.Blue;
            this.summoner.TabIndex = 7;
            this.summoner.Text = "Player 1";
            this.summoner.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.summoner.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.summoner.UseSelectable = true;
            this.summoner.UseStyleColors = true;
            this.summoner.MouseEnter += new System.EventHandler(this.summoner_MouseEnter);
            // 
            // Player2Ctrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lmkslb);
            this.Controls.Add(this.dmgdealtlb);
            this.Controls.Add(this.dmgtakenlb);
            this.Controls.Add(this.Turretdestlb);
            this.Controls.Add(this.wardkilledlb);
            this.Controls.Add(this.wardplacedlb);
            this.Controls.Add(this.creepslb);
            this.Controls.Add(this.goldlb);
            this.Controls.Add(this.item7);
            this.Controls.Add(this.item6);
            this.Controls.Add(this.item5);
            this.Controls.Add(this.item4);
            this.Controls.Add(this.item3);
            this.Controls.Add(this.item2);
            this.Controls.Add(this.item1);
            this.Controls.Add(this.KDAlb);
            this.Controls.Add(this.Spell2);
            this.Controls.Add(this.Spell1);
            this.Controls.Add(this.Champion);
            this.Controls.Add(this.summoner);
            this.Name = "Player2Ctrl";
            this.Size = new System.Drawing.Size(983, 37);
            ((System.ComponentModel.ISupportInitialize)(this.Spell2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spell1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Champion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.item7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Spell2;
        private System.Windows.Forms.PictureBox Spell1;
        private System.Windows.Forms.PictureBox Champion;
        private MetroFramework.Controls.MetroLink summoner;
        private MetroFramework.Controls.MetroLabel KDAlb;
        private System.Windows.Forms.PictureBox item1;
        private System.Windows.Forms.PictureBox item2;
        private System.Windows.Forms.PictureBox item3;
        private System.Windows.Forms.PictureBox item4;
        private System.Windows.Forms.PictureBox item5;
        private System.Windows.Forms.PictureBox item6;
        private System.Windows.Forms.PictureBox item7;
        private MetroFramework.Controls.MetroLabel goldlb;
        private MetroFramework.Controls.MetroLabel creepslb;
        private MetroFramework.Controls.MetroLabel wardplacedlb;
        private MetroFramework.Controls.MetroLabel wardkilledlb;
        private MetroFramework.Controls.MetroLabel dmgdealtlb;
        private MetroFramework.Controls.MetroLabel dmgtakenlb;
        private MetroFramework.Controls.MetroLabel Turretdestlb;
        private MetroFramework.Controls.MetroLabel lmkslb;
    }
}
